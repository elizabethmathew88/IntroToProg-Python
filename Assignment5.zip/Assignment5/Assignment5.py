'''When the program starts, load each row of data 
from the ToDo.txt text file into a Python dictionary.'''
lstTable=[]
lstRow=[]
dicRow={}
objFile=open("C:\\PythonClass\\ToDo.txt","r")
for line in objFile:
    lstRow=str(line).split(',')
    dicRow={"Task":lstRow[0],"Priority":lstRow[1].strip('\n')}
    lstTable.append(dicRow)
objFile.close()
print("The existing list:")
print(lstTable)


# After you get the data in a Python dictionary,
# add the new dictionary “row” into a Python list object
while(True):
    strV=input("Do you want to add a new task to the list?(y/n): ")
    if(strV.lower()=='y'):
        newTask=input("Enter a new task: ")
        priority=input("Enter its priority: ")
        dicNewRow={"Task":newTask,"Priority":priority}
        lstTable.append(dicNewRow)
    else:break
print(lstTable)


# Allow the user to Add or Remove tasks from the list using numbered choices.
while(True):
    print("\n")
    print("Options:")
    print("1: Show current data")
    print("2: Add a new item")
    print("3: Remove an existing item")
    print("4: Save Data to File")
    print("5: Exit Program")
    strV=input("Select an option(1-5):")
    if(strV=='1'):
        print("The list is: ")
        print(lstTable)
    elif(strV=='2'):
        found=0
        newTask = input("Enter a new task: ")
        for dicRow in lstTable:
            if newTask.lower() in str(dicRow.values()).lower():
                found=1
        if(found==1):
            print("Task already exists")
        else:
            priority = input("Enter its priority: ")
            dicNewRow = {"Task": newTask, "Priority": priority}
            lstTable.append(dicNewRow)
            print("Task added")
    elif(strV=='3'):
        found=0
        strTask=input("Enter the task to be removed: ")
        for dicRow in lstTable:
            if strTask.lower() in str(dicRow.values()).lower():
                lstTable.remove(dicRow)
                found = 1
        if(found==1):
            print("Task removed")
        else:
            print("Task not found")
    elif(strV=='4'):
        objFile = open("C:\\PythonClass\\ToDo.txt", "w")
        objFile.write("TASK & PRIORITY \n")
        objFile.write("---------------\n")
        for dicrow in lstTable:
            objFile.write(str(dicrow["Task"])+" - " +str(dicrow["Priority"])+ "\n")
        objFile.close()
        print("The list is saved in the text file ToDo.txt")
    else:break
