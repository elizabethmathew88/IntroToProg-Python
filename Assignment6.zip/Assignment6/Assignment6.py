#------------------------------------
#Title: Using classes and functions
#Date:5/15/2017
#------------------------------------

objFileName="C:\\PythonClass\\ToDo.txt"
lstTable=[]
lstRow=[]
dicRow={}

class ToDo(object):
    def ReadFile(self):
        '''
        Function to read the data from text file 
        '''
        objFile = open(objFileName, "r")
        for line in objFile:
            lstRow = str(line).split(',')
            dicRow = {"Task": lstRow[0], "Priority": lstRow[1].strip('\n')}
            lstTable.append(dicRow)
        objFile.close()
        return lstTable

    def Display(self):
        '''
        Function to display the contents of the list to the user 
        '''
        print("The current list is: ")
        print(lstTable)

    def AddItem(newTask,priority):
        '''
        Function to add a task 
        '''
        dicNewRow = {"Task": newTask, "Priority": priority}
        lstTable.append(dicNewRow)
        return lstTable

    def RemoveItem(strTask):
        '''
        Function to remove a task 
        '''
        for dicRow in lstTable:
            if strTask.lower() in str(dicRow.values()).lower():
                lstTable.remove(dicRow)
        return lstTable

    def WriteToFile(self):
        '''
        Function to write the data to text file 
        '''
        objFile = open(objFileName, "w")
        for dicrow in lstTable:
            objFile.write(str(dicrow["Task"]) + "," + str(dicrow["Priority"]) + "\n")
        objFile.close()

obj=ToDo()
obj.ReadFile()
while(True):
    print("\n")
    print("The current list is:")
    print(lstTable)
    print("Options:")
    print("1: Show current data")
    print("2: Add a new item")
    print("3: Remove an existing item")
    print("4: Save Data to File")
    print("5: Exit Program")
    strV=input("Select an option(1-5):")
    if(strV=='1'):
        obj.Display()
    elif (strV == '2'):
        found = 0
        newTask = input("Enter a new task: ")
        for dicRow in lstTable:
            if newTask.lower() in str(dicRow.values()).lower():
                found = 1
        if (found == 1):
            print("Task already exists")
        else:
            priority = input("Enter its priority(high/low): ")
            ToDo.AddItem(newTask,priority)
            print("Task added")
    elif (strV == '3'):
        found = 0
        strTask = input("Enter the task to be removed: ")
        for dicRow in lstTable:
            if strTask.lower() in str(dicRow.values()).lower():
                found = 1
        if (found == 1):
            ToDo.RemoveItem(strTask)
            print("Task removed")
        else:
            print("Task not found")
    elif (strV == '4'):
        obj.WriteToFile()
        print("The list is saved in the text file ToDo.txt")
    else:
        break

